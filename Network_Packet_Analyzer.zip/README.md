# Network Packet Analyzer

## Description
This is a basic packet sniffer tool that captures and analyzes network packets. It displays:
- Source and destination IP addresses.
- Protocols (TCP/UDP).
- Payload data (if available).

**Note**: This tool is for educational purposes only. Ensure ethical use with proper permissions.

## Features
- Captures network packets using the `scapy` library.
- Provides detailed information about the packets.

## Requirements
- Python 3.x
- `scapy` library (`pip install scapy`)

## How to Use
1. Run the script with administrator/root privileges:
   ```bash
   sudo python network_packet_analyzer.py
   ```
2. The tool will capture 10 packets by default and display details in the terminal.

## Ethical Guidelines
- Always obtain explicit permission before capturing network packets.
- Do not use this tool for malicious or unauthorized activities.

## License
This project is licensed under the MIT License.
